import requests 

#The api key:
api_address="http://api.openweathermap.org/data/2.5/weather?appid=4d91fff58578156a6ef98d890a78e98c&q="
city = input("City Name: ")
url = api_address + city

response = requests.get(url)
x = response.json()


if x["cod"] != "404":
  temp = x['main']['temp'] - 273.15
  temp = int(temp * 9/5 + 32)
  conditions = x['weather'][0]['description']
  country = x['sys']['country'] 
  print(f"Temp in {city} ({country}), is {temp} degrees with {conditions}.")
else:
  print(f"'{city}' not found as city in database.")  




